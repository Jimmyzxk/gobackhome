'use strict';

const Server = require('../lib/Server');

module.exports = new Server();
