'use strict';

const childProcess = require('child_process');
const { release } = require('./package.json');

module.exports.RELEASE = release;
module.exports.PORT = process.env.PORT || '51821';
module.exports.WEBUI_HOST = process.env.WEBUI_HOST || '0.0.0.0';
module.exports.PASSWORD = process.env.PASSWORD || '';
module.exports.PASSWORD_HASH = process.env.PASSWORD_HASH;
module.exports.WG_PATH = process.env.WG_PATH || '/etc/wireguard/';
module.exports.WG_DEVICE = process.env.WG_DEVICE || 'ens18';
module.exports.WG_HOST = process.env.WG_HOST || 'home.gogai.my';
module.exports.WG_PORT = process.env.WG_PORT || '51820';
module.exports.WG_CONFIG_PORT = process.env.WG_CONFIG_PORT || process.env.WG_PORT || '51820';
module.exports.WG_MTU = process.env.WG_MTU || '1280';
module.exports.WG_PERSISTENT_KEEPALIVE = process.env.WG_PERSISTENT_KEEPALIVE || '20';
module.exports.WG_DEFAULT_ADDRESS = process.env.WG_DEFAULT_ADDRESS || '10.8.0.x';
module.exports.WG_DEFAULT_ADDRESS6 = process.env.WG_DEFAULT_ADDRESS6 || 'fdcc:cafe:8888::x';
module.exports.WG_DEFAULT_DNS = typeof process.env.WG_DEFAULT_DNS === 'string'
  ? process.env.WG_DEFAULT_DNS
  : '10.10.10.40';
module.exports.WG_DEFAULT_DNS6 = typeof process.env.WG_DEFAULT_DNS6 === 'string'
  ? process.env.WG_DEFAULT_DNS6
  : 'dc00::6666';
module.exports.WG_ALLOWED_IPS = process.env.WG_ALLOWED_IPS || 'dc00::/64, 10.10.10.0/24, f2b0::/18, 28.0.0.0/8, 10.8.0.0/24, fdcc:cafe:8888::/64, 91.108.56.0/22, 91.108.4.0/22, 91.108.8.0/22, 91.108.16.0/22, 91.108.12.0/22, 149.154.160.0/20, 91.105.192.0/23, 91.108.20.0/22, 185.76.151.0/24, 2001:67c:4e8::/48, 2001:b28:f23f::/48, 2a0a:f280::/32, 2001:b28:f23c::/48, 2001:b28:f23d::/48';

module.exports.WG_PRE_UP = process.env.WG_PRE_UP || '';
module.exports.WG_POST_UP = process.env.WG_POST_UP;
if (!process.env.WG_POST_UP) {
  module.exports.WG_POST_UP = `
  iptables -t nat -A POSTROUTING -s ${module.exports.WG_DEFAULT_ADDRESS.replace('x', '0')}/24 -o ${module.exports.WG_DEVICE} -j MASQUERADE;
  iptables -A INPUT -p udp -m udp --dport 51820 -j ACCEPT;
  iptables -A FORWARD -i wg0 -j ACCEPT;
  iptables -A FORWARD -o wg0 -j ACCEPT;
  ip6tables -t nat -A POSTROUTING -s ${module.exports.WG_DEFAULT_ADDRESS6.replace('x', '0')}/64 -o ${module.exports.WG_DEVICE} -j MASQUERADE;
  ip6tables -A INPUT -p udp -m udp --dport 51820 -j ACCEPT;
  ip6tables -A FORWARD -i wg0 -j ACCEPT;
  ip6tables -A FORWARD -o wg0 -j ACCEPT;`;

  module.exports.WG_POST_UP = module.exports.WG_POST_UP.split('\n').join(' ');
}

module.exports.WG_PRE_DOWN = process.env.WG_PRE_DOWN || '';
module.exports.WG_POST_DOWN = process.env.WG_POST_DOWN;
if (!process.env.WG_POST_DOWN) {
  module.exports.WG_POST_DOWN = `
  iptables -t nat -D POSTROUTING -s ${module.exports.WG_DEFAULT_ADDRESS.replace('x', '0')}/24 -o ${module.exports.WG_DEVICE} -j MASQUERADE;
  iptables -D INPUT -p udp -m udp --dport ${module.exports.WG_PORT} -j ACCEPT;
  iptables -D FORWARD -i wg0 -j ACCEPT;
  iptables -D FORWARD -o wg0 -j ACCEPT;
  ip6tables -t nat -D POSTROUTING -s ${module.exports.WG_DEFAULT_ADDRESS6.replace('x', '0')}/64 -o ${module.exports.WG_DEVICE} -j MASQUERADE;
  ip6tables -D INPUT -p udp -m udp --dport 51820 -j ACCEPT;
  ip6tables -D FORWARD -i wg0 -j ACCEPT;
  ip6tables -D FORWARD -o wg0 -j ACCEPT;`;

  module.exports.WG_POST_DOWN = module.exports.WG_POST_DOWN.split('\n').join(' ');
}

module.exports.LANG = process.env.LANG || 'chs';
module.exports.UI_TRAFFIC_STATS = process.env.UI_TRAFFIC_STATS || 'true';
module.exports.UI_CHART_TYPE = process.env.UI_CHART_TYPE || 1;